from setuptools import setup, find_packages

setup(
    name='tasks_dags',
    version='0.1.0',
    description='Pacote com tasks e logger para Airflow',
    author='Seu Nome',
    author_email='seu.email@exemplo.com',
    packages=find_packages(where='src'),   # vai procurar dentro de src
    package_dir={'': 'src'},                # raiz dos pacotes é src/
    install_requires=[
        # coloque aqui suas dependências se tiver
    ],
    python_requires='>=3.7',
)
